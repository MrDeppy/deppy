﻿Imports TechLifeForum
Public Class Form1
    Dim WithEvents irc As IrcClient
    Public Sub Conectar()
        irc = New IrcClient("chat.freenode.net:6666")
        irc.Nick = txtNick.Text
        irc.JoinChannel("##C++")
        irc.Connect()
        lblStatos.Text = "Conectado Servidor Irc."
    End Sub

    Public Sub ircChannelMessage(sender As Object, e As ChannelMessageEventArgs) Handles irc.ChannelMessage
        txtMensagens.AppendText(Message & vbNewLine)
        txtMensagens.ScrollToCaret()
        lblMensagens.Text = "Lendo Mensagens."
        txtMensagens.Text = irc.ToString
    End Sub
    Private Sub btnConectar_Click(sender As Object, e As EventArgs) Handles btnConectar.Click
        Conectar()
    End Sub
End Class
